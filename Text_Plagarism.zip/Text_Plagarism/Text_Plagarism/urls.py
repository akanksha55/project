"""
URL configuration for Text_Plagarism project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from users import views as user
from admins import views as admins
urlpatterns = [
    path('admin/', admin.site.urls),
    path("index.html", user.index, name="index"),
    path("Register.html", user.Register, name="Register"),
    path("Signup", user.Signup, name="Signup"),
    path("Login.html", user.Login, name="Login"),
    path("UserLogin", user.UserLogin, name="UserLogin"),
    path("UploadSource", user.UploadSource, name="UploadSource"),
    path("UploadSource1", user.UploadSource1, name="UploadSource1"),
    path("UploadSourceImage", user.UploadSourceImage, name="UploadSourceImage"),
    path("UploadSourceImage1", user.UploadSourceImage1, name="UploadSourceImage1"),
    path("UploadSuspiciousFile", user.UploadSuspiciousFile, name="UploadSuspiciousFile"),
    path("UploadSuspiciousFileAction", user.UploadSuspiciousFileAction, name="UploadSuspiciousFileAction"),
    path("UploadSuspiciousImage", user.UploadSuspiciousImage, name="UploadSuspiciousImage"),
    path("UploadSuspiciousImageAction", user.UploadSuspiciousImageAction, name="UploadSuspiciousImageAction"),
    

    path("AdminLogin",admins.alogin, name="AdminLogin"),
    path("UploadSourceFile1",admins.uploadsource1, name="UploadSourceFile1"),
    path("UploadSourceImages",admins.uploadimage, name="UploadSourceImages"),
    path("UserList",admins.userlist, name="userlist"),

]
