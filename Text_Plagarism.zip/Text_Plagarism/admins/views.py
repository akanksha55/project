
from django.shortcuts import render
import os
import pymysql
from django.conf import settings
# Create your views here.
def alogin(request):
    if request.method=="POST":
        username = request.POST.get('username', False)
        password = request.POST.get('password', False)
        if username=="admin" and password=="admin":
            context= {'data':'welcome admin'}
            return render(request,"AdminScreen.html", context)
        else:
            context= {'data':'login failed'}
            return render(request, 'AdminLogin.html', context)
    return render(request,"AdminLogin.html")

def uploadsource(request):
    if request.method == 'POST' and request.FILES.get('t1'):
        print("upload")
        uploaded_file = request.FILES['t1']
        # Construct the path relative to BASE_DIR
        destination_path = os.path.join(settings.BASE_DIR, 'corpus-20090418', uploaded_file.name)
        # Ensure the directory exists
        os.makedirs(os.path.dirname(destination_path), exist_ok=True)
        # Write the file to the destination
        with open(destination_path, 'wb+') as destination:
            for chunk in uploaded_file.chunks():
                destination.write(chunk)
        uploaded_file_url = '/corpus-20090418/' + uploaded_file.name
        return render(request,"UploadSourceFile1.html")
    return render(request,"UploadSourceFile1.html")

def uploadsource1(request):
    if request.method == 'POST' and request.FILES.get('t1'):
        print("upload1")
        uploaded_file = request.FILES['t1']
        # Construct the path relative to BASE_DIR
        destination_path = os.path.join(settings.BASE_DIR, 'corpus-20090418', uploaded_file.name)
        # Ensure the directory exists
        os.makedirs(os.path.dirname(destination_path), exist_ok=True)
        # Write the file to the destination
        with open(destination_path, 'wb+') as destination:
            for chunk in uploaded_file.chunks():
                destination.write(chunk)
        uploaded_file_url = '/corpus-20090418/' + uploaded_file.name
        return render(request,"UploadSourceFile1.html")
    return render(request,"UploadSourceFile1.html")
    
def uploadimage(request):
    if request.method == 'POST' and request.FILES.get('t1'):
        uploaded_file = request.FILES['t1']
        # Construct the path relative to BASE_DIR
        destination_path = os.path.join(settings.BASE_DIR, 'images', uploaded_file.name)
        # Ensure the directory exists
        os.makedirs(os.path.dirname(destination_path), exist_ok=True)
        # Write the file to the destination
        with open(destination_path, 'wb+') as destination:
            for chunk in uploaded_file.chunks():
                destination.write(chunk)
        uploaded_file_url = '/images/' + uploaded_file.name
        return render(request,"UploadNewImage.html")
    return render(request,"UploadNewImage.html")

def userlist(request):
    users = None
    con = pymysql.connect(host='127.0.0.1', port=3306, user='root', password='', database='plagiarism', charset='utf8')
    with con:
        cur = con.cursor()
        cur.execute("SELECT * FROM users")
        users = cur.fetchall()

    context = {'users': users}  # Pass users to the context
    return render(request, 'User_List.html', context)